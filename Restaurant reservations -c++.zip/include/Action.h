#ifndef ACTION_H_
#define ACTION_H_

#include <string>
#include <iostream>
#include "Customer.h"

enum ActionStatus{
	PENDING, COMPLETED, ERROR
};


//Forward declaration
class Restaurant;
//class Table;

class BaseAction{
public:
	BaseAction();
	virtual ~BaseAction()=0;
	ActionStatus getStatus() const;
	void setStatus(ActionStatus st);
	std::string getStringStatus() const;
	virtual void act(Restaurant& restaurant)=0;
	virtual std::string toString() const=0;
	virtual BaseAction* clone()  =0;
	virtual void Delete()=0;
protected:
	void complete();
	void error(std::string errorMsg);
	std::string getErrorMsg() const;
private:
	std::string errorMsg;
	ActionStatus status;
};


class OpenTable : public BaseAction {
public:
	OpenTable(int id, std::vector<Customer *> &customersList);
	OpenTable(const OpenTable &other);
	OpenTable(OpenTable&& other);
	virtual ~OpenTable();
	void act(Restaurant &restaurant);
	std::string toString() const;
	OpenTable* clone();
    virtual void Delete();
private:
	const int tableId;
	std::vector<Customer*> customers;
};


class Order : public BaseAction {
public:
    virtual ~Order();
	Order(int id);
	void act(Restaurant &restaurant);
	std::string toString() const;
	Order* clone();
    virtual void Delete();
private:
	const int tableId;
};

class MoveCustomer : public BaseAction {
public:
    virtual ~MoveCustomer();
	MoveCustomer(int src, int dst, int customerId);
	void act(Restaurant &restaurant);
	std::string toString() const;
	MoveCustomer* clone();
    virtual void Delete();
private:
	const int srcTable;
	const int dstTable;
	const int id;
};


class Close : public BaseAction {
public:
    virtual ~Close();
	Close(int id);
	void act(Restaurant &restaurant);
	std::string toString() const;
	Close* clone();
    virtual void Delete();
private:
	const int tableId;
};


class CloseAll : public BaseAction {
public:
    virtual ~CloseAll();
	CloseAll();
	void act(Restaurant &restaurant);
	std::string toString() const;
	CloseAll* clone();
    virtual void Delete();
private:
};


class PrintMenu : public BaseAction {
public:
    virtual ~PrintMenu();
	PrintMenu();
	void act(Restaurant &restaurant);
	std::string toString() const;
	PrintMenu* clone();
    virtual void Delete();
private:
};


class PrintTableStatus : public BaseAction {
public:
    virtual ~PrintTableStatus();
	PrintTableStatus(int id);
	void act(Restaurant &restaurant);
	std::string toString() const;
	PrintTableStatus* clone();
    virtual void Delete();
private:
	const int tableId;
};


class PrintActionsLog : public BaseAction {
public:
    virtual ~PrintActionsLog();
	PrintActionsLog();
	void act(Restaurant &restaurant);
	std::string toString() const;
	PrintActionsLog* clone();
    virtual void Delete();
private:
};


class BackupRestaurant : public BaseAction {
public:
    virtual ~BackupRestaurant();
	BackupRestaurant();
	void act(Restaurant &restaurant);
	std::string toString() const;
	BackupRestaurant* clone();
    virtual void Delete();
private:
};


class RestoreRestaurant : public BaseAction {
public:
    virtual ~RestoreRestaurant();
	RestoreRestaurant();
	void act(Restaurant &restaurant);
	std::string toString() const;
	RestoreRestaurant* clone();
    virtual void Delete();
};


#endif