#include "Restaurant.h"
#include <fstream>
#include <vector>
#include <string>
#include <iostream>
using namespace std;


Restaurant::Restaurant(): open(true), c_id(0),tables(),menu(),actionsLog() {}

Restaurant::Restaurant(const std::string &configFilePath): Restaurant() {
    vector<string> vStr;
    //int hTC = 0;
    int tblNum = 0;
    int d_id=0;
    string line;
    fstream strm;
    strm.open(configFilePath);
    while (getline(strm, line)) {
        if (static_cast<int>(line.size()) > 0 && line[0] != '#')
            vStr.push_back(line);
    }
    tblNum=stoi(vStr[0]);
    string tmp=(vStr[1]);
    string capa;
    size_t cmIndex = 0;
    while (static_cast<int>(tables.size()) < tblNum) {
        cmIndex = tmp.find(',');
        if (cmIndex > 0) {
            capa = tmp.substr(0, cmIndex);
            tmp = tmp.substr(cmIndex + 1);
            Table* tbl=new Table(stoi(capa));
            tables.push_back(tbl);
        } else {
            Table* tbl=new Table(stoi(tmp));
            tables.push_back(tbl);
        }
    }
    for (int i = 2; i < static_cast<int>(vStr.size()); ++i) {
        string d_Line=(vStr[i]);
        string d_name;
        int d_price=0;
        string d_strtype;
        DishType d_type;
        size_t d_comma = d_Line.find(',');
        d_name = d_Line.substr(0, d_comma);
        d_Line = d_Line.substr(d_comma+1);

        d_comma = d_Line.find(',');
        d_strtype = d_Line.substr(0, d_comma);
        if (d_strtype == "VEG") {
            d_type = VEG;
        }
        if (d_strtype == "SPC") {
            d_type = SPC;
        }
        if (d_strtype == "BVG") {
            d_type = BVG;
        }
        if (d_strtype == "ALC") {
            d_type = ALC;
        }

        d_Line = d_Line.substr(d_comma+1);

        d_price = (stoi(d_Line));

        Dish dish= Dish(d_id, d_name, d_price, d_type);
        menu.push_back(dish);
        d_id++;
    }
    strm.close();
}

//Distructor
Restaurant::~Restaurant() {
    clear();
}

//Copy Constructor
Restaurant::Restaurant(const Restaurant &other): open(other.open), c_id(other.c_id), tables(),menu(), actionsLog() {
    copy(other);
}

//Copy Assingment operator
Restaurant& Restaurant::operator=(const Restaurant& other) {
    if(&other != this){
        open=other.open;
        c_id=other.c_id;
        clear();
        copy(other);
    }
    return *this;
}

//move constructor
Restaurant::Restaurant(Restaurant &&other): open(other.open), c_id(other.c_id),tables(), menu(),actionsLog() {
    move(other);
}

//move Assingment operator
Restaurant& Restaurant::operator=(Restaurant &&other) {

    clear();
    move(other);
    return *this;
}

//clear
void Restaurant::clear() {
    for (int i = 0; i <static_cast<int>(tables.size()) ; ++i) {
        delete tables[i];
        tables[i]= nullptr;
    }
    tables.clear();

    for (int j = 0; j <static_cast<int>(actionsLog.size()) ; ++j) {
        actionsLog[j]->Delete();
        actionsLog[j]= nullptr;
    }
    actionsLog.clear();
    menu.clear();
}

//copy
void Restaurant::copy(const Restaurant &other) {

    for (int i = 0; i < static_cast<int>(other.tables.size()); ++i) {
        tables.push_back(new Table(*other.tables[i]));
    }
    for (int j = 0; j < static_cast<int>(other.actionsLog.size()); ++j) {
        actionsLog.push_back(other.actionsLog[j]->clone());
    }
    for (int k = 0; k < static_cast<int>(other.menu.size()) ; ++k) {
        menu.push_back(other.menu[k]);
    }
}
//move
void Restaurant::move(Restaurant &other) {
    this->tables=other.tables;
    this->actionsLog=other.actionsLog;
    for (int i = 0; i < static_cast<int>(other.tables.size()) ; ++i) {
        other.tables[i]= nullptr;
    }
    other.tables.clear();
    for (int i = 0; i < static_cast<int>(other.actionsLog.size()) ; ++i){
        other.actionsLog[i]= nullptr;
    }
    other.actionsLog.clear();
    for (int j = 0; j < static_cast<int>(other.menu.size()); ++j) {
        menu.push_back(other.menu[j]);
    }
}


void Restaurant::start() {
    open=true;
    cout<<"Restaurant is now open!"<<endl;
    string action;
    getline(cin,action);
    while (action!="closeall"){
        if (action.substr(0,4)=="open"){
            string tmpLine;
            action=action.substr(5);
            int t_id = stoi(action.substr(0,action.find(' ')));
            vector<Customer*> tmpVecCus;
            action=action.substr(action.find(' ')+1);
            int space=-1;
            space=action.find(' ');
            while (space!=-1){
                tmpLine=action.substr(0,space);
                string name = tmpLine.substr(0,tmpLine.find(','));
                string strategy = tmpLine.substr(tmpLine.find(',')+1);
                if (strategy=="veg"){
                    VegetarianCustomer* vegetarianCustomer=new VegetarianCustomer(name, c_id) ;
                    tmpVecCus.push_back(vegetarianCustomer);
                }
                if (strategy=="chp"){
                    CheapCustomer* cheapCustomer=new CheapCustomer (name,c_id);
                    tmpVecCus.push_back(cheapCustomer);
                }
                if (strategy=="spc"){
                    SpicyCustomer* spicyCustomer=new SpicyCustomer (name,c_id);
                    tmpVecCus.push_back(spicyCustomer);
                }
                if (strategy=="alc"){
                    AlchoholicCustomer* alchoholicCustomer=new AlchoholicCustomer (name,c_id);
                    tmpVecCus.push_back(alchoholicCustomer);
                }
                action=action.substr(space+1);
                c_id++;
                space=action.find(' ');
            }
            string name = action.substr(0,action.find(','));
            string strategy = action.substr(action.find(',')+1);
            if (strategy=="veg"){
                VegetarianCustomer* vegetarianCustomer=new VegetarianCustomer(name, c_id) ;
                tmpVecCus.push_back(vegetarianCustomer);
            }
            if (strategy=="chp"){
                CheapCustomer* cheapCustomer=new CheapCustomer (name,c_id);
                tmpVecCus.push_back(cheapCustomer);
            }
            if (strategy=="spc"){
                SpicyCustomer* spicyCustomer=new SpicyCustomer (name,c_id);
                tmpVecCus.push_back(spicyCustomer);
            }
            if (strategy=="alc"){
                AlchoholicCustomer* alchoholicCustomer=new AlchoholicCustomer (name,c_id);
                tmpVecCus.push_back(alchoholicCustomer);
            }
            c_id++;
            BaseAction* bsAc = new OpenTable(t_id,tmpVecCus);
            bsAc->act(*this);
            actionsLog.push_back(bsAc);
        }
        if (action.substr(0,5)=="order"){
            int num_Table= stoi(action.substr(action.find(' ')+1));
            Order* order=new Order(num_Table);
            order->act(*this);
            actionsLog.push_back(order);
        }

        if (action.substr(0,4)=="move"){

            action=action.substr(5);
            string origTableS = action.substr(0,action.find(' '));
            string destTableS = action.substr(action.find(' ')+1,action.rfind(' ')-action.find(' '));
            string c_idS = action.substr(action.rfind(' '));
            int origTable = stoi(origTableS);
            int destTable = stoi(destTableS);
            int c_id = stoi(c_idS);
            BaseAction *bsAc = new MoveCustomer(origTable,destTable,c_id);
            bsAc->act(*this);
            actionsLog.push_back(bsAc);
        }
        if (action.substr(0,5)=="close"){
            int num_Table= stoi(action.substr(action.find(' ')+1));
            BaseAction* close=new Close(num_Table);
            close->act(*this);
            actionsLog.push_back(close);
        }
        if (action.substr(0,4)=="menu"){
            BaseAction* menu=new PrintMenu();
            menu->act(*this);
            actionsLog.push_back(menu);
        }
        if (action.substr(0,6)=="status"){
            int num_Table= stoi(action.substr(action.find(' ')+1));
            BaseAction* printTableStatus=new PrintTableStatus(num_Table);
            printTableStatus->act(*this);
            actionsLog.push_back(printTableStatus);
        }
        if (action.substr(0,3)=="log"){
            BaseAction* printActionsLog = new PrintActionsLog();
            printActionsLog->act(*this);
            actionsLog.push_back(printActionsLog);
        }
        if (action.substr(0,6)=="backup"){
            BaseAction* backup= new BackupRestaurant();
            backup->act(*this);
            actionsLog.push_back(backup);
        }
        if (action.substr(0,7)=="restore"){

            BaseAction* restore= new RestoreRestaurant();
            restore->act(*this);
            actionsLog.push_back(restore);
        }
        getline(cin,action);
    }
    if (action.substr(0,8)=="closeall"){

        BaseAction* closeAll=new CloseAll();
        closeAll->act(*this);
        actionsLog.push_back(closeAll);
    }
}

int Restaurant::getNumOfTables() const {
    return static_cast<int>(tables.size());
}

Table* Restaurant::getTable(int ind) {
    return tables[ind];
}


const std::vector<BaseAction*>& Restaurant::getActionsLog() const {
    return actionsLog;
}

vector<Dish>& Restaurant::getMenu() {
    return menu;
}