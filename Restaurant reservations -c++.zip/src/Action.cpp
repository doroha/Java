#include "Action.h"
#include <vector>
#include <string>
#include <iostream>
#include "Restaurant.h"

extern Restaurant* backup;
using namespace std;
// ------------------------------------- BaseAction -------------------------------------

BaseAction::BaseAction(): errorMsg(""), status(PENDING) {}

BaseAction::~BaseAction() {}

ActionStatus BaseAction::getStatus() const {
    return status;
}

void BaseAction::setStatus(ActionStatus st) {
    this->status=st;
}

std::string BaseAction::getStringStatus() const {
    if (status==PENDING) return "Pending";
    if (status==COMPLETED) return "Completed";
    return "Error";
}

void BaseAction::complete() {
    this->status=COMPLETED;
}

void BaseAction::error(std::string errorMsg) {
    this->status = ERROR;
    this->errorMsg = errorMsg;
    cout << "Error: " << errorMsg << endl;
}

std::string BaseAction::getErrorMsg() const {
    return errorMsg;
}

// ------------------------------------- OpenTable -------------------------------------

//constructor
OpenTable::OpenTable(int id, std::vector<Customer *> &customersList) :BaseAction(), tableId(id), customers(customersList) {}
//distructor
OpenTable::~OpenTable() {}

void OpenTable::Delete() {
    for(int i=0; i<(int)(customers.size()); i++)
        customers[i]->Delete();
    delete this;}

//copyCunstructor
OpenTable::OpenTable(const OpenTable &other): tableId(other.tableId), customers() {
    for (int i = 0; i < static_cast<int>(other.customers.size()); ++i) {
        customers.push_back(other.customers[i]->clone());
    }
    this->setStatus(other.getStatus());
}

//moveCunstructor
OpenTable::OpenTable(OpenTable &&other): tableId(other.tableId), customers() {
    this->customers=other.customers;
    for (int i = 0; i < static_cast<int>(other.customers.size()) ; ++i) {
        other.customers[i]= nullptr;
    }
    other.customers.clear();
}

void OpenTable::act(Restaurant &restaurant) {

    if (tableId >= restaurant.getNumOfTables() || tableId < 0 || restaurant.getTable(tableId)->isOpen()) {
        error("Table does not exist or is already open");
    }
    else {
        int cusCount = static_cast<int>(customers.size());
        Table *tbl = restaurant.getTable(tableId);
        if (cusCount > tbl->getCapacity()) {
            error("Table does not exist or is already open");
        }
        else {
            for (int i=0; i<static_cast<int>(customers.size()); ++i){
                tbl->addCustomer(customers[i]->clone());
            }
            tbl->openTable();
            complete();
        }
    }
}

std::string OpenTable::toString() const {
    string str="";
    for (int i = 0; i < static_cast<int>(customers.size()); ++i) {
        str= str + customers[i]->toString() + " " ;
    }
    if (getStringStatus()=="Completed")
        return "open " + to_string(tableId) + " " + str + getStringStatus();
    else return "open " + to_string(tableId) + " " + str + getStringStatus() + ": " + getErrorMsg();
}

OpenTable* OpenTable::clone() { return new OpenTable(*this); }


// ------------------------------------- Order -------------------------------------

Order::Order(int id):BaseAction(), tableId(id){}

Order::~Order() {}

void Order::act(Restaurant &restaurant) {

    Table *table = restaurant.getTable(tableId);

    if (tableId >= restaurant.getNumOfTables() || tableId < 0 || !table->isOpen())
        error("Table does not exist or is already open");
    else {
        table->order(restaurant.getMenu());

        for (int i = static_cast<int>(table->getOrders().size()) - table->getCountNewOrder();
             i < static_cast<int>(table->getOrders().size()); ++i) {
            cout << table->getCustomerById(table->getOrders()[i].first)->getName() << " " << "ordered" << " "
                 << table->getOrders()[i].second.getName() << endl;
        }
        complete();
    }
}

std::string Order::toString() const {
    if (getStringStatus()=="Completed")
        return "order " + to_string(tableId) + " " + getStringStatus();
    else  return "order " + to_string(tableId) + " " + getStringStatus()+": " +getErrorMsg();
}

Order* Order::clone() {
    return new Order(*this);
}

void Order::Delete() { delete this;}



// ------------------------------------- MoveCustomer -------------------------------------

MoveCustomer::MoveCustomer(int src, int dst, int customerId):BaseAction(), srcTable(src), dstTable(dst), id(customerId) {}

MoveCustomer::~MoveCustomer() {}

void MoveCustomer::act(Restaurant &restaurant) {

    Table *src_Table = restaurant.getTable(srcTable);
    Table *dst_Table = restaurant.getTable(dstTable);


    if (!src_Table->isOpen() || !dst_Table->isOpen() || srcTable > restaurant.getNumOfTables() || dstTable > restaurant.getNumOfTables() || src_Table->getCustomer(id)== nullptr || dst_Table->getCountCustomers() == dst_Table->getCapacity() ) {
        error("Cannot move customer");
    } else{

        vector<OrderPair> moveOrder;

        for (int i = 0; i < static_cast<int>(src_Table->getOrders().size()) ; ++i) {

            if (src_Table->getOrders()[i].first == id) {
                moveOrder.push_back(src_Table->getOrders()[i]);
            }
        }

        dst_Table->addMovedCustomer(src_Table->getCustomer(id), moveOrder);

        src_Table->removeCustomer(id);

        if (src_Table->getCountCustomers()  == 0) {
            Close close(srcTable);
            close.act(restaurant);
        }
        complete();
    }
}

std::string MoveCustomer::toString() const {
    if (getStringStatus()=="Completed")
        return "move " + to_string(srcTable) +  " " + to_string(dstTable) + " " + to_string(id) + " " + getStringStatus();
    else return "move " + to_string(srcTable) +  " " + to_string(dstTable) + " " + to_string(id) + " " + getStringStatus() + ": " + getErrorMsg();
}

MoveCustomer* MoveCustomer::clone() {
    return new MoveCustomer(*this);
}

void MoveCustomer::Delete() { delete this;}

// ------------------------------------- Close -------------------------------------

Close::Close(int id):BaseAction(), tableId(id) {}

Close::~Close() {}

void Close::act(Restaurant &restaurant) {

    if (tableId > restaurant.getNumOfTables())  error("Table does not exist or is not open");


    if (!(restaurant.getTable(tableId)->isOpen())) error("Table does not exist or is not open");

int bill=0;
    for (int i = 0; i < static_cast<int>(restaurant.getTable(tableId)->getOrders().size()) ; ++i) {
        bill+= restaurant.getTable(tableId)->getOrders()[i].second.getPrice();
    }

    restaurant.getTable(tableId)->clear();

    restaurant.getTable(tableId)->getOrders().clear();
    restaurant.getTable(tableId)->closeTable();
    complete();
    cout << "Table " << to_string(tableId) << " was closed. Bill " << to_string(bill) << "NIS" <<endl;
}

std::string Close::toString() const {
    if (getStringStatus()=="Completed")
        return  "Closed Table: " + to_string(tableId) + " " + getStringStatus();
    else return  "Closed Table: " + to_string(tableId) + getStringStatus() + ": " + getErrorMsg();
}
Close* Close::clone() {
    return new Close(*this);
}

void Close::Delete() { delete this;}


// ------------------------------------- CloseAll -------------------------------------

CloseAll::CloseAll():BaseAction() {}

CloseAll::~CloseAll() {}

void CloseAll::act(Restaurant &restaurant) {


    for (int i = 0; i < restaurant.getNumOfTables(); ++i) {
        Table *tbl=restaurant.getTable(i);
        if (tbl->isOpen()) {
            Close table(i);
            table.act(restaurant);
        }
    }
}

std::string CloseAll::toString() const {
    return "Resturant Close";
}

CloseAll* CloseAll::clone() {
    return new CloseAll(*this);
}

void CloseAll::Delete() { delete this;}


// ------------------------------------- PrintMenu -------------------------------------

PrintMenu::PrintMenu():BaseAction() {}

PrintMenu::~PrintMenu() {}

void PrintMenu::act(Restaurant &restaurant) {

    for (int i = 0; i <static_cast<int>(restaurant.getMenu().size()) ; ++i) {
        cout << restaurant.getMenu()[i].getName() << " " << restaurant.getMenu()[i].getDishTipeName() << restaurant.getMenu()[i].getPrice() << "NIS" << endl;
    }
}
std::string PrintMenu::toString() const {
    return "Print menu" + getStringStatus();
}

PrintMenu* PrintMenu::clone() {
    return new PrintMenu(*this);
}

void PrintMenu::Delete() { delete this;}


// ------------------------------------- PrintTableStatus -------------------------------------

PrintTableStatus::PrintTableStatus(int id):BaseAction(), tableId(id) {}

PrintTableStatus::~PrintTableStatus() {}

void PrintTableStatus::act(Restaurant &restaurant) {

    Table *table=restaurant.getTable(tableId);

    if (table->isOpen()){

        cout << "Table " << to_string(tableId) << " status: " << "open" << endl;
        cout << "Customers:" << endl;
        for (int i = 0; i < static_cast<int>(table->getCustomers().size()) ; ++i) {
            cout << table->getCustomers()[i]->getId() << " " << table->getCustomers()[i]->getName() << endl;
        }
        cout << "Orders:" << endl;
        for (int i = 0; i < static_cast<int>(table->getOrders().size()) ; ++i) {
            cout << table->getOrders()[i].second.getName() << " " << table->getOrders()[i].second.getPrice() << "NIS " <<  table->getOrders()[i].first <<  endl;
        }

        int bill=0;
        for (int i = 0; i < static_cast<int>(table->getOrders().size()) ; ++i) {
            bill+= table->getOrders()[i].second.getPrice();
        }
        cout << "Current Bill: "<< bill << "NIS"<< endl;

    } else if (!table->isOpen()) {
        cout << "Table " << to_string(tableId) << " status: " << "closed" << endl;
    }
    complete();
}

std::string PrintTableStatus::toString() const {
    return "status " + to_string(tableId) + " " + getStringStatus();
}

PrintTableStatus* PrintTableStatus::clone() {
    return new PrintTableStatus(*this);
}

void PrintTableStatus::Delete() { delete this;}


// ------------------------------------- Print action log-------------------------------------

PrintActionsLog::PrintActionsLog():BaseAction() {}

PrintActionsLog::~PrintActionsLog() {}

void PrintActionsLog::act(Restaurant &restaurant) {

    for (int i = 0; i < static_cast<int>(restaurant.getActionsLog().size()) ; ++i) {
        cout << restaurant.getActionsLog()[i]->toString() <<  endl;
    }
    complete();
}
std::string PrintActionsLog::toString() const {
    return "log " + getStringStatus();
}

PrintActionsLog* PrintActionsLog::clone() {
    return new PrintActionsLog(*this);
}

void PrintActionsLog::Delete() { delete this;}


// ------------------------------------- BackupRestaurant------------------------------------

BackupRestaurant::BackupRestaurant():BaseAction() {}

BackupRestaurant::~BackupRestaurant() {}

void BackupRestaurant::act(Restaurant &restaurant) {


    if (backup == nullptr) {
        backup=new Restaurant(restaurant);
    } else if (backup != nullptr){
        delete backup;
        backup= nullptr;
        backup=new Restaurant(restaurant);
    }
    complete();
}

std::string BackupRestaurant::toString() const {
    return "backup " + getStringStatus();
}

BackupRestaurant* BackupRestaurant::clone() {
    return new BackupRestaurant(*this);
}

void BackupRestaurant::Delete() { delete this;}


// ------------------------------------- RestoreResturant------------------------------------

RestoreRestaurant::RestoreRestaurant():BaseAction() {}

RestoreRestaurant::~RestoreRestaurant() {}

void RestoreRestaurant::act(Restaurant &restaurant) {

    if (backup == nullptr) { error("No backup available"); }
    else {
        restaurant = *backup;
    }
    complete();
}

std::string RestoreRestaurant::toString() const {
    if (getStringStatus()=="Completed")
        return "restore " + getStringStatus();
    else return "restore " + getStringStatus()+ ": " + getErrorMsg();
}

RestoreRestaurant* RestoreRestaurant::clone() {
    return new RestoreRestaurant(*this);
}

void RestoreRestaurant::Delete() { delete this;}
