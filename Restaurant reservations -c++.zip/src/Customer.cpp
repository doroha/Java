#include "Customer.h"

#include <vector>
#include <string>
#include "Dish.h"
using namespace std;


Customer::Customer(std::string c_name, int c_id) : name(c_name) , id(c_id)  {}

Customer::~Customer() {}

std::string Customer::getName() const {
    return name;
}

int Customer::getId() const {
    return id;
}

// ------------------------------- Vegeterian --------------------------------------

VegetarianCustomer::VegetarianCustomer(std::string name, int id):Customer(name,id){}

void VegetarianCustomer::Delete() { delete this;}

VegetarianCustomer::~VegetarianCustomer() {}

std::vector<int> VegetarianCustomer::order(const std::vector<Dish> &menu) {

    vector<int> veg_Order;
    int min_ID=-1;
    int max_Price = 0;
    int max_PriceID=0;
    bool foundVEG = false;
    bool foundBVG = false;

    for (int (i) = 0; (i) < static_cast<int>(menu.size()) ; ++(i)) {
        if (menu[i].getType() == VEG) {
            if (min_ID == -1 || menu[i].getId() < min_ID) {
                min_ID = menu[i].getId();
                foundVEG=true;
            }
        }
        if (menu[i].getType() == BVG) {
            if (max_Price == 0 || menu[i].getPrice() > max_Price) {
                max_Price = menu[i].getPrice();
                max_PriceID = menu[i].getId();
                foundBVG=true;
            }
        }
    }
    if (min_ID!=0 && max_PriceID!=0 && foundBVG && foundVEG) {
        veg_Order.push_back(min_ID);
        veg_Order.push_back(max_PriceID);
    }

    return veg_Order;
}

VegetarianCustomer* VegetarianCustomer::clone() {
    return new VegetarianCustomer(*this);
}

std::string VegetarianCustomer::toString() const {
    return  getName() + "," + "veg" ;
}


// --------------------------------- Cheap ------------------------------------------

CheapCustomer::CheapCustomer(std::string name, int id): Customer(name,id), orderOnce(false){}

void CheapCustomer::Delete() { delete this;}

CheapCustomer::~CheapCustomer() {}

vector<int> CheapCustomer::order(const std::vector<Dish> &menu) {

    vector<int> chp_Order;
    int min_ID = 0;
    int min_Price = 0;
    for (int i = 0; i < static_cast<int>(menu.size()) && !orderOnce; ++i) {
        if (min_Price == 0 || menu[i].getPrice() < min_Price) {
            min_Price = menu[i].getPrice();
            min_ID = (menu[i].getId());
        }
    }
    if (min_ID != 0 && min_Price != 0 && !orderOnce) {
        chp_Order.push_back(min_ID);
        orderOnce = true;
    }
    return chp_Order;
}
CheapCustomer* CheapCustomer::clone() {
    return new CheapCustomer(*this);
}

string CheapCustomer::toString() const {
    return  getName() + "," + "chp" ;
}

// ------------------------------------ Spicy ------------------------------------

SpicyCustomer::SpicyCustomer(std::string name, int id):Customer(name,id), orderOnce(false){}

void SpicyCustomer::Delete() { delete this;}

SpicyCustomer::~SpicyCustomer() {}

vector<int> SpicyCustomer::order(const std::vector<Dish> &menu) {

    vector<int> spc_Order;
    int maxSpcPrice=0;
    int maxSpcID=-1;
    int minBvgPrice = 0;
    int minBvgID = -1;
    for (int i = 0; i < static_cast<int>(menu.size()); ++i) {
        if(menu[i].getType()==SPC && !orderOnce){
            if (maxSpcPrice==0 || menu[i].getPrice()>maxSpcPrice){
                maxSpcPrice=menu[i].getPrice();
                maxSpcID=(menu[i].getId());
            }
        }
        if (menu[i].getType()==BVG && orderOnce){
            if (minBvgPrice==0 || menu[i].getPrice()<minBvgPrice){
                minBvgPrice=menu[i].getPrice();
                minBvgID=menu[i].getId();
            }
        }
    }
    if (maxSpcPrice!=0 && maxSpcID!=-1 && !orderOnce){
        spc_Order.push_back(maxSpcID);
        orderOnce = true;
    }

    if (minBvgID!=-1 && minBvgPrice!=0 && orderOnce){
        spc_Order.push_back(minBvgID);
    }
    return spc_Order;
}
SpicyCustomer* SpicyCustomer::clone() {
    return new SpicyCustomer(*this);
}

string SpicyCustomer::toString() const {
    return  getName() + "," + "spc" ;
}

// ------------------------------------ Alchoholic ------------------------------------

AlchoholicCustomer::AlchoholicCustomer(std::string name, int id):Customer(name,id) ,first_Time(true), cheapest_Cost(0) ,cheapest_ID(0) , mostExpensive_Cost(0), mostExpensive_id(0) {}

void AlchoholicCustomer::Delete() { delete this;}

AlchoholicCustomer::~AlchoholicCustomer() {}

std::vector<int> AlchoholicCustomer::order(const std::vector<Dish> &menu) {

    vector<int> alc_Order;

    if (first_Time) {

        for (int (i) = 0; (i) < static_cast<int>(menu.size()); ++(i)) {
            if (menu[i].getType() == ALC) {
                cheapest_Cost = menu[i].getPrice();
                cheapest_ID = menu[i].getId();
                mostExpensive_Cost=menu[i].getPrice();
                mostExpensive_id=menu[i].getId();
                break;
            }
        }
        for (int (i) = 0; (i) < static_cast<int>(menu.size()); ++(i)) {
            if (menu[i].getType() == ALC) {
                if (menu[i].getPrice() == cheapest_Cost) {
                    if (menu[i].getId()<cheapest_ID) {
                        cheapest_Cost = menu[i].getPrice();
                        cheapest_ID = menu[i].getId();
                    }
                } else if (menu[i].getPrice() < cheapest_Cost){
                    cheapest_Cost = menu[i].getPrice();
                    cheapest_ID = menu[i].getId();
                }

                if (menu[i].getPrice() == mostExpensive_Cost) {
                    if (menu[i].getId()>mostExpensive_id) {
                        mostExpensive_Cost = menu[i].getPrice();
                        mostExpensive_id = menu[i].getId();
                    }
                } else if (menu[i].getPrice() > mostExpensive_Cost){
                    mostExpensive_Cost = menu[i].getPrice();
                    mostExpensive_id = menu[i].getId();
                }
            }
        }
        alc_Order.push_back(cheapest_ID);
    }

    if (!first_Time && cheapest_ID!=mostExpensive_id) {

        bool found= false;
        for (int i = cheapest_ID; i < static_cast<int>(menu.size()); ++i) {
            if (menu[i].getType() == ALC) {
                if ((menu[i].getPrice() == cheapest_Cost) && (menu[i].getId() != cheapest_ID)) {
                    cheapest_Cost = menu[i].getPrice();
                    cheapest_ID = menu[i].getId();
                    found= true;
                    break;
                }
            }
        }
        if (!found){
            int min=cheapest_Cost;
            for (int i = 0; i < static_cast<int>(menu.size()) ; ++i) {
                if (menu[i].getType() == ALC) {
                    if (menu[i].getPrice()> min) {
                        cheapest_Cost=menu[i].getPrice();
                        cheapest_ID=menu[i].getId();
                        break;
                    }
                }
            }
            for (int j = 0; j < static_cast<int>(menu.size()) ; ++j) {
                if (menu[j].getType()==ALC){
                    if ((menu[j].getPrice()<cheapest_Cost) && (menu[j].getPrice() > min) ){
                        cheapest_Cost=menu[j].getPrice();
                        cheapest_ID=menu[j].getId();
                    } else if(menu[j].getPrice()==cheapest_Cost  && menu[j].getId()<cheapest_ID){
                        cheapest_Cost=menu[j].getPrice();
                        cheapest_ID=menu[j].getId();
                    }
                }
            }
        }
        alc_Order.push_back(cheapest_ID);
    }

    first_Time= false;
    return alc_Order;
}
AlchoholicCustomer* AlchoholicCustomer::clone() {
    return new AlchoholicCustomer(*this);
}

std::string AlchoholicCustomer::toString() const {
    return  getName() + "," + "alc" ;
}