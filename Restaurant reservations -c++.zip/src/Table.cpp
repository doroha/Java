#include "Table.h"
#include <vector>

using namespace std;

//Counstructor
Table::Table(int t_capacity) : capacity(t_capacity), open(false), customersList(),orderList() , countNewOrder(0) {}

void Table::addCustomer(Customer *customer) {

    if (static_cast<int>(customersList.size()) < capacity) {
        customersList.push_back(customer);
    }
}

//Distractor
Table::~Table() {
    clear();
}

//Copy Constructor
Table::Table(const Table &other): capacity(other.capacity), open(other.open) ,customersList(), orderList(),countNewOrder(other.countNewOrder) {

    copy(other);
}
//Copy Assingment operator
Table& Table::operator=(const Table &other) {

    if (this != &other){
        capacity=other.capacity;
        open=other.open;
        clear();
        copy(other);
    }
    return *this;
}

//move constructor
Table::Table(Table &&other): capacity(other.capacity),open(other.open), customersList(),orderList(), countNewOrder(other.countNewOrder) {

    move(other);
}

//move Assingment operator
Table& Table::operator=(Table &&other) {

    clear();
    move(other);
    return *this;
}

//copy an object
void Table::copy(const Table &other) {

    for (int i = 0; i <static_cast<int>(other.customersList.size()) ; ++i) {
        customersList.push_back(other.customersList[i]->clone());
    }
    for (int j = 0; j <static_cast<int>(other.orderList.size()) ; ++j) {
        orderList.push_back(other.orderList[j]);
    }
}

//clear the object
void Table::clear() {
    for (int i = 0; i < static_cast<int>(customersList.size()) ; ++i) {
        customersList[i]->Delete();
        customersList[i]= nullptr;
    }
    customersList.clear();
    orderList.clear();
}


//move an object
void Table::move(Table &other) {

    this->customersList=other.customersList;

    for (int j = 0; j < static_cast<int>(other.orderList.size()) ; ++j) {
        orderList.push_back(other.orderList[j]);
    }
    // other.orderList.clear();
    for (int i = 0; i < static_cast<int>(other.customersList.size()) ; ++i) {
        other.customersList[i]= nullptr;
    }
    other.customersList.clear();
}

void Table::closeTable() {

    if(open) open = false;
}

int Table::getCapacity() const {
    return capacity;
}

Customer* Table::getCustomer(int id) {

    bool  found= false;
    for (int i = 0; i < static_cast<int>(customersList.size()) && !found ; ++i) {

        if(customersList[i]->getId()==id) {
            found= true;
            return customersList[i];
        }
    }
    return nullptr;
}

std::vector<Customer *> & Table::getCustomers() { return customersList;}

std::vector<OrderPair> & Table::getOrders() { return orderList; }

bool Table::isOpen() {
    return open;
}

void Table::openTable() {
    if(!open) open =true;
}

void Table::order(const std::vector <Dish> &menu) {

    countNewOrder=0;
    vector<int> order_Custumer;
    for (int i = 0; i < static_cast<int>(customersList.size()) ; ++(i)) {

        order_Custumer=customersList[i]->order(menu);

        for (int j = 0; j < static_cast<int>(order_Custumer.size()); ++j) {
            OrderPair pair = OrderPair(customersList[i]->getId(), menu[order_Custumer[j]]);
            orderList.push_back(pair);
            countNewOrder++;
        }
    }
}

int Table::getCountCustomers() {
    return static_cast<int>(customersList.size());
}

int Table::getCountNewOrder() {
    return countNewOrder;
}

void Table::removeCustomer(int id) {
    int index;
    bool  found= false;
    for (int i = 0; i < static_cast<int>(customersList.size()) && !found ; ++i) {

        if(customersList[i]->getId()==id) {
            found= true;
            index=i;
        }
    }

    customersList.erase(customersList.begin() + index);

    vector<OrderPair> orderTokeep;
    for (int j = 0; j <static_cast<int>(orderList.size()) ; ++j) {
        if (orderList[j].first!=id) orderTokeep.push_back(orderList[j]);
    }
    orderList.clear();
    for (int k = 0; k <static_cast<int>(orderTokeep.size()); ++k) {
        orderList.push_back(orderTokeep[k]);
    }
}


Table* Table::clone() {
    return new Table(*this);
}

Customer* Table::getCustomerById(int id) {
    for (int i = 0; i < static_cast<int>(customersList.size()) ; ++i) {
        if (customersList[i]->getId()==id)
            return customersList[i];
    }
    return nullptr;
}

void Table::addMovedCustomer(Customer *customer, std::vector<OrderPair> orders) {

    for (OrderPair op : orders)
        orderList.push_back(op);

    customersList.push_back(customer);

}
